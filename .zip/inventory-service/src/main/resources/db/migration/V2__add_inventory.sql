INSERT INTO t_inventory (quantity, sku_code)
VALUES
    (100,'SKU001'),
    (100,'SKU002'),
    (100,'SKU003'),
    (100,'SKU004'),
    (100,'SKU005');