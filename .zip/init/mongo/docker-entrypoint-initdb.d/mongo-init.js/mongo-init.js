print('START');

db = db.getSiblingDB('product-service');

db.createUser(
    {
        user: 'admin',
        pwd: 'password',
        roles: [{ role: 'admin', db: 'product-service' }]
    }
);

db.createCollection('user');

print('END');