rootProject.name = "microservice-parent"

include("product-service", "order-service", "inventory-service")
